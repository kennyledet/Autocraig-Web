import datetime
from mongokit import Connection, Document

# Database config and init
MONGODB_HOST = 'localhost'
MONGODB_PORT = 27017
connection   = Connection()